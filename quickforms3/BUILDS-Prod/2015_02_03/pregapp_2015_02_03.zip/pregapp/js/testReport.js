define(['dom/form/form','server/getFactData','helper/md5'],
function (){
quickforms.getFactData({queryName:'getReport'
                        
                       });
	alert();
});