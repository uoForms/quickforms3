  define(function(){ 
        var config = {};
        config.app = 'ReportProblems';
        config.loginLocation = 'index.html';
        config.extraScripts=['js/auth.js'];
        
        config.dataTransferType = "text";
        return config;
});