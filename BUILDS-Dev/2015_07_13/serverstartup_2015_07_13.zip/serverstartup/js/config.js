define(function(){ 
        var config = {};
        config.app = 'serverstartup';
        config.loginLocation = 'index.html';
        config.extraScripts=[];
        
        config.dataTransferType = "text";
        config.description = "Server Startup App";
        return config;
});