define(function(){
	var config = {};
	config.offline = true;
	return config;
});
