define(function(){
	var config = {};
	config.offline = true;
	config.extraScripts=[];
	config.debug = false;
	return config;
});
