define(function(){
	var config = {};
	config.offline = true;
	config.extraScripts=[];
	return config;
});
