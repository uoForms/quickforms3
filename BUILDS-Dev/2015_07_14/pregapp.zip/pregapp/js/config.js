   define(function(){
	  var config = {};
    config.app = 'pregapp';
	config.loginLocation = 'index.html';
	config.extraScripts=['js/authSaid.js'];
	//config.quickformsUrl = 'http://quickforms3.eecs.uottawa.ca/quickforms/';
	config.dataTransferType = "text";
	return config;
   });