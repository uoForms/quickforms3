define(function(){ 
	var config = {};
	config.app = 'pregapp';
	//config.debug = false;
	config.loginLocation = '../index.html';
	config.extraScripts=['../js/authSaid.js'];
	//config.quickformsUrl = 'http://quickforms3.eecs.uottawa.ca/quickforms/';
	config.dataTransferType = "text";
	return config;
});

