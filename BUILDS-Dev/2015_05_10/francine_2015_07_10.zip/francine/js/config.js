   define(function(){
      var config = {};
      config.app = 'pregapp'; // Your App name
	  config.jqueryMobileTheme = "/francine/css/theme.css"; 
	  //config.jqueryMobilePath="/francine/js/jquery.mobile-1.2.0";
	  //config.jqueryMobileCss="/francine/css/mobile.css";
      config.extraScripts = [];
      config.quickformsEnding = ""; // "" or ".asp"
	  config.defaultPageTransition = "none"; // slide, pop, none
	  config.defaultDialogTransition = "pop"; // slide, pop, none	  
      return config;
	  
   });